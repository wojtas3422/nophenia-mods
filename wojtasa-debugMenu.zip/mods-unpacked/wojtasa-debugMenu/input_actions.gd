# input_actions.gd - key mapping for the nophenia debug menu (Godot 4).
#
# Reads raw physical keys / keycodes instead of registering InputMap actions, so
# it never clobbers the game's own input and is layout-independent for movement.
#
# F1 is the separate "Sightless Lite" mod. F11/F12 are left alone (Steam uses
# them for screenshots), so the debug menu lives on F2-F8.
#
# Controls:
#   F2  toggle debug overlay        F6  open/close spawn menu
#   F3  toggle noclip               F7  emergency "unstuck" (nudge up)
#   F4  toggle fly / free movement  F8  Sightless Lite calibration (needs the mod)
#   F5  toggle freecam              =/+ increase speed   -  decrease speed   0 reset
#
# (Coordinates are shown live on the F2 overlay; F10 opens the phone Debug page.)
#
# Movement while noclip/fly/freecam is active:
#   W/A/S/D move, Space = up, Shift = down (relative to the camera).

class_name NopheniaDebugInput
extends RefCounted

const ACT_TOGGLE_OVERLAY := "toggle_overlay"
const ACT_TOGGLE_NOCLIP := "toggle_noclip"
const ACT_TOGGLE_FLY := "toggle_fly"
const ACT_TOGGLE_FREECAM := "toggle_freecam"
const ACT_PRINT_COORDS := "print_coords"
const ACT_TOGGLE_SPAWN := "toggle_spawn"
const ACT_UNSTUCK := "unstuck"
const ACT_TOGGLE_CALIBRATION := "toggle_calibration"
const ACT_SPEED_UP := "speed_up"
const ACT_SPEED_DOWN := "speed_down"
const ACT_SPEED_RESET := "speed_reset"


# Returns the action string for a key-press event, or "" if none matches.
static func action_for_event(event: InputEvent) -> String:
	if not (event is InputEventKey):
		return ""
	var key_event := event as InputEventKey
	if not key_event.pressed or key_event.echo:
		return ""
	match key_event.keycode:
		KEY_F2:
			return ACT_TOGGLE_OVERLAY
		KEY_F3:
			return ACT_TOGGLE_NOCLIP
		KEY_F4:
			return ACT_TOGGLE_FLY
		KEY_F5:
			return ACT_TOGGLE_FREECAM
		KEY_F6:
			return ACT_TOGGLE_SPAWN
		KEY_F7:
			return ACT_UNSTUCK
		KEY_F8:
			return ACT_TOGGLE_CALIBRATION
		KEY_EQUAL, KEY_KP_ADD:
			return ACT_SPEED_UP
		KEY_MINUS, KEY_KP_SUBTRACT:
			return ACT_SPEED_DOWN
		KEY_0, KEY_KP_0:
			return ACT_SPEED_RESET
	return ""


# Raw movement axes as a Vector3(right, up, forward), each in [-1, 1].
# The caller maps these onto a camera basis.
static func movement_axis() -> Vector3:
	var forward := 0.0
	if Input.is_physical_key_pressed(KEY_W):
		forward += 1.0
	if Input.is_physical_key_pressed(KEY_S):
		forward -= 1.0
	var right := 0.0
	if Input.is_physical_key_pressed(KEY_D):
		right += 1.0
	if Input.is_physical_key_pressed(KEY_A):
		right -= 1.0
	var up := 0.0
	if Input.is_physical_key_pressed(KEY_SPACE):
		up += 1.0
	if Input.is_physical_key_pressed(KEY_SHIFT):
		up -= 1.0
	return Vector3(right, up, forward)
