# debug_overlay.gd - minimal, readable on-screen status panel (Godot 4).
#
# Created and driven by debug_tools.gd. It is intentionally dependency-free: it
# builds its own Label/Panel at runtime so it works whether the mod was added to
# a loose project or repacked into a .pck.

extends CanvasLayer

var _content: PanelContainer
var _label: Label
var _shown := true


func _ready() -> void:
	layer = 128  # draw above the game's own UI
	_content = PanelContainer.new()
	_content.position = Vector2(12, 12)
	_content.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.55)
	style.set_corner_radius_all(4)
	style.set_content_margin_all(8)
	_content.add_theme_stylebox_override("panel", style)
	add_child(_content)

	_label = Label.new()
	_label.add_theme_font_size_override("font_size", 14)
	_label.add_theme_color_override("font_color", Color(0.85, 1.0, 0.85))
	_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	_label.add_theme_constant_override("outline_size", 2)
	_content.add_child(_label)

	_label.text = "[Debug Menu] F2 to toggle overlay"


func toggle() -> void:
	_shown = not _shown
	if _content != null:
		_content.visible = _shown


func set_overlay_visible(value: bool) -> void:
	_shown = value
	if _content != null:
		_content.visible = value


func update_state(state: Dictionary) -> void:
	if _label == null or not _shown:
		return

	var on := func(b): return "ON" if b else "off"
	var lines: Array[String] = []
	lines.append("nophenia Debug Control Panel")
	lines.append("debug    : %s" % on.call(state.get("enabled", true)))

	if state.get("network_detected", false):
		lines.append("!! MULTIPLAYER/NETWORK DETECTED: movement disabled")
	elif not state.get("movement_allowed", true):
		lines.append("!! multiplayer content flagged: movement disabled")

	lines.append("noclip   : %s" % on.call(state.get("noclip", false)))
	lines.append("fly      : %s" % on.call(state.get("fly", false)))
	lines.append("freecam  : %s" % on.call(state.get("freecam", false)))
	lines.append("speed    : x%0.2f" % float(state.get("speed", 1.0)))

	var pos: Vector3 = state.get("pos", Vector3.ZERO)
	if state.get("has_player", false):
		lines.append("coords   : (%.2f, %.2f, %.2f)" % [pos.x, pos.y, pos.z])
	else:
		lines.append("coords   : (no player node found: see config.json)")

	lines.append("scene    : %s" % String(state.get("scene", "?")))
	if state.get("flashlight_present", false):
		lines.append("Sightless Lite: %s   (F1)" % ("ON" if state.get("flashlight", false) else "off"))
	lines.append("[F2 panel  F3 noclip  F4 fly  F5 freecam]")
	lines.append("[F6 menu  F7 unstuck  F8 SL-calib  F10 phone]")

	var fl_debug := String(state.get("flashlight_debug", ""))
	if fl_debug != "":
		lines.append(fl_debug)

	var message := String(state.get("message", ""))
	if message != "":
		lines.append("> %s" % message)

	lines.append("credits: Nodesrelda AKA Nodesclock :D")
	_label.text = "\n".join(lines)

	# Tint the panel red while networked/disabled so it's unmistakable.
	var disabled: bool = bool(state.get("network_detected", false)) or not bool(state.get("movement_allowed", true))
	var style := _content.get_theme_stylebox("panel") as StyleBoxFlat
	if style != null:
		style.bg_color = Color(0.30, 0.0, 0.0, 0.6) if disabled else Color(0.0, 0.0, 0.0, 0.55)
