# debug_tools.gd - "Nophenia Debug Menu" mod (autoload NopheniaDebug).
#
# On-screen overlay + noclip / fly / freecam / speed / coordinate readout /
# spawn menu. Plus the CALIBRATION tool (F8), which drives the separate
# "Sightless Lite" mod if installed.
#
# Keys live on F2-F8 (F1 = Sightless Lite; F11/F12 are Steam screenshot keys).
#
# SAFETY: single-player/offline only. If a multiplayer/network session (or a
# multiplayer mod flagged at patch time) is detected, gameplay-altering features
# are force-disabled. No process/memory hacks - ordinary in-engine GDScript.

extends Node

const DInput := preload("res://mods-unpacked/wojtasa-debugMenu/input_actions.gd")
const OVERLAY_PATH := "res://mods-unpacked/wojtasa-debugMenu/debug_overlay.gd"
const SPAWN_PATH := "res://mods-unpacked/wojtasa-debugMenu/spawn_menu.gd"
const PHONE_PATH := "res://mods-unpacked/wojtasa-debugMenu/phone_menu.gd"
const PATCH_CONFIG_PATH := "res://mods-unpacked/wojtasa-debugMenu/patch_config.json"

const CONFIG_DIR := "user://nophenia_debug"
const USER_CONFIG_PATH := CONFIG_DIR + "/config.json"

const SPEED_MIN := 0.1
const SPEED_MAX := 20.0
const BASE_SPEED := 6.0
const FLY_SPEED_SCALE := 0.45

const PLAYER_GROUPS := ["player", "Player", "players", "characters"]
const PLAYER_NAME_HINTS := [
	"player", "character", "firstpersoncontroller", "fpscontroller",
	"fpcontroller", "pawn", "protagonist", "controller",
]

# ---- runtime state -------------------------------------------------------- #
var enabled := true
var noclip := false
var fly := false
var freecam := false
var speed_multiplier := 1.0

var movement_allowed := true
var spawn_allowed := true
var network_detected := false

var player: Node = null
var _player_node_path := ""

var _collision_saved := false
var _orig_collision_layer := 0
var _orig_collision_mask := 0

# Grounded noclip: keep the player "on the floor" (so the game lets the phone
# open) by colliding ONLY with an invisible follower floor while passing through
# all real geometry. Disable via config "noclip_grounded": false (classic noclip).
const NC_FLOOR_BIT := 1 << 19   # collision layer 20 - unused by the game
var _noclip_grounded := true
var _nc_floor: StaticBody3D = null
var _nc_feet_offset := 0.0
var _nc_orig_snap := 0.0
var _nc_snap_saved := false

var _ctrl_pos := Vector3.ZERO
var _ctrl_active := false

var _freecam_node: Camera3D = null
var _prev_camera: Camera3D = null
var _prev_mouse_mode := Input.MOUSE_MODE_VISIBLE
var _freecam_yaw := 0.0
var _freecam_pitch := 0.0

var _overlay: CanvasLayer = null
var _spawn_menu: CanvasLayer = null
var _phone_menu: CanvasLayer = null

var _last_message := ""
var _message_timer := 0.0

var _fl_calibrating := false  # F8 calibration mode (controls the Sightless Lite mod)

# In-game phone-menu integration (see phone_menu.gd).
var _phone_integration := true
var _phone_mode := "auto"          # auto | native | overlay | off
var _phone_native_injection := true
var _phone_overlay_fallback := true
var _phone_entry_label := "Debug"
var _phone_open_key := "D"
var _phone_force_native := false
var _phone_menu_container_path := ""
var _phone_insert_before_text := "End Program"
var _phone_insert_after_text := "Kitty"


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_priority = 1000
	set("process_physics_priority", 1000)
	_load_patch_config()
	_ensure_config_dir()
	_load_user_config()
	_build_overlay()
	_build_spawn_menu()
	_build_phone_menu()
	_print_banner()
	call_deferred("_refresh_player")


# --------------------------------------------------------------------------- #
# Config / persistence
# --------------------------------------------------------------------------- #


func _load_patch_config() -> void:
	if not ResourceLoader.exists(PATCH_CONFIG_PATH) and not FileAccess.file_exists(PATCH_CONFIG_PATH):
		return
	var f := FileAccess.open(PATCH_CONFIG_PATH, FileAccess.READ)
	if f == null:
		return
	var data: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(data) != TYPE_DICTIONARY:
		return
	if data.has("movement_features_allowed"):
		movement_allowed = bool(data["movement_features_allowed"])
	if data.has("spawn_menu_allowed"):
		spawn_allowed = bool(data["spawn_menu_allowed"])
	if not movement_allowed:
		_flash("Static scan flagged multiplayer content: movement disabled.")


func _ensure_config_dir() -> void:
	if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(CONFIG_DIR)):
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(CONFIG_DIR))


func _load_user_config() -> void:
	if not FileAccess.file_exists(USER_CONFIG_PATH):
		return
	var f := FileAccess.open(USER_CONFIG_PATH, FileAccess.READ)
	if f == null:
		return
	var data: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(data) != TYPE_DICTIONARY:
		return
	_player_node_path = String(data.get("player_node_path", ""))
	speed_multiplier = clampf(float(data.get("speed_multiplier", 1.0)), SPEED_MIN, SPEED_MAX)
	_noclip_grounded = bool(data.get("noclip_grounded", true))
	_phone_integration = bool(data.get("debug_phone_integration", true))
	_phone_mode = String(data.get("debug_phone_mode", "auto"))
	_phone_native_injection = bool(data.get("debug_phone_native_injection", true))
	_phone_overlay_fallback = bool(data.get("debug_phone_overlay_fallback", true))
	_phone_entry_label = String(data.get("debug_phone_entry_label", "Debug"))
	_phone_open_key = String(data.get("debug_phone_open_key", "D"))
	_phone_force_native = bool(data.get("debug_phone_force_native", false))
	_phone_menu_container_path = String(data.get("debug_phone_menu_container_path", ""))
	_phone_insert_before_text = String(data.get("debug_phone_insert_before_text", "End Program"))
	_phone_insert_after_text = String(data.get("debug_phone_insert_after_text", "Kitty"))


func _save_user_config() -> void:
	var f := FileAccess.open(USER_CONFIG_PATH, FileAccess.WRITE)
	if f == null:
		return
	var data := {
		"player_node_path": _player_node_path,
		"speed_multiplier": speed_multiplier,
		"noclip_grounded": _noclip_grounded,
		"debug_phone_integration": _phone_integration,
		"debug_phone_mode": _phone_mode,
		"debug_phone_native_injection": _phone_native_injection,
		"debug_phone_overlay_fallback": _phone_overlay_fallback,
		"debug_phone_entry_label": _phone_entry_label,
		"debug_phone_open_key": _phone_open_key,
		"debug_phone_force_native": _phone_force_native,
		"debug_phone_menu_container_path": _phone_menu_container_path,
		"debug_phone_insert_before_text": _phone_insert_before_text,
		"debug_phone_insert_after_text": _phone_insert_after_text,
	}
	f.store_string(JSON.stringify(data, "\t"))
	f.close()


# --------------------------------------------------------------------------- #
# UI children
# --------------------------------------------------------------------------- #


func _build_overlay() -> void:
	var script := load(OVERLAY_PATH)
	if script == null:
		return
	_overlay = script.new()
	add_child(_overlay)


func _build_spawn_menu() -> void:
	var script := load(SPAWN_PATH)
	if script == null:
		return
	_spawn_menu = script.new()
	add_child(_spawn_menu)
	if _spawn_menu.has_method("setup"):
		_spawn_menu.setup(self)


func _build_phone_menu() -> void:
	var script := load(PHONE_PATH)
	if script == null:
		return
	_phone_menu = script.new()
	add_child(_phone_menu)
	if _phone_menu.has_method("setup"):
		_phone_menu.setup(self, {
			"integration": _phone_integration,
			"mode": _phone_mode,
			"native_injection": _phone_native_injection,
			"overlay_fallback": _phone_overlay_fallback,
			"entry_label": _phone_entry_label,
			"open_key": _phone_open_key,
			"force_native": _phone_force_native,
			"menu_container_path": _phone_menu_container_path,
			"insert_before_text": _phone_insert_before_text,
			"insert_after_text": _phone_insert_after_text,
		})


# --------------------------------------------------------------------------- #
# Player discovery
# --------------------------------------------------------------------------- #


func _refresh_player() -> Node:
	if player != null and is_instance_valid(player):
		return player
	player = null
	if _player_node_path != "":
		player = get_node_or_null(NodePath(_player_node_path))
		if player != null:
			return player
	var tree := get_tree()
	if tree == null:
		return null
	for group_name in PLAYER_GROUPS:
		var nodes := tree.get_nodes_in_group(group_name)
		if nodes.size() > 0:
			player = nodes[0]
			return player
	player = _auto_find_player(tree.current_scene)
	return player


func _auto_find_player(root: Node) -> Node:
	if root == null:
		return null
	var cb := _find_node_of_class(root, "CharacterBody3D")
	if cb != null:
		return cb
	var by_name := _find_node_by_name_hint(root)
	if by_name != null:
		return by_name
	return _find_node_of_class(root, "RigidBody3D")


func _find_node_of_class(node: Node, klass: String) -> Node:
	if node == null:
		return null
	if node.is_class(klass):
		return node
	for child in node.get_children():
		var found := _find_node_of_class(child, klass)
		if found != null:
			return found
	return null


func _find_node_by_name_hint(node: Node) -> Node:
	if node == null:
		return null
	var lname := String(node.name).to_lower()
	for hint in PLAYER_NAME_HINTS:
		if lname.find(hint) != -1 and node is Node3D:
			return node
	for child in node.get_children():
		var found := _find_node_by_name_hint(child)
		if found != null:
			return found
	return null


func _player_spatial() -> Node3D:
	if player != null and player is Node3D:
		return player
	return null


func _player_collision_object() -> CollisionObject3D:
	if player == null:
		return null
	if player is CollisionObject3D:
		return player
	return _find_node_of_class(player, "CollisionObject3D") as CollisionObject3D


func _flashlight_mod() -> Node:
	# The separate Sightless Lite mod's autoload, if it's installed (else null).
	return get_tree().get_first_node_in_group("nophenia_flashlight")


func _phone_is_open() -> bool:
	return _phone_menu != null and is_instance_valid(_phone_menu) \
		and _phone_menu.has_method("is_phone_open") and _phone_menu.is_phone_open()


# Hide the on-screen Debug Control Panel overlay (F10). F2 brings it back.
func hide_overlay() -> void:
	if _overlay != null and is_instance_valid(_overlay) and _overlay.has_method("set_overlay_visible"):
		_overlay.set_overlay_visible(false)


# --------------------------------------------------------------------------- #
# Input
# --------------------------------------------------------------------------- #


func _input(event: InputEvent) -> void:
	if freecam and event is InputEventMouseMotion:
		_freecam_mouse(event as InputEventMouseMotion)
		return
	# Live flashlight calibration intercepts its keys first (arrows / R / K).
	if _fl_calibrating and event is InputEventKey:
		var ke := event as InputEventKey
		if ke.pressed and not ke.echo and _handle_calibration_key(ke):
			get_viewport().set_input_as_handled()
			return
	var action := DInput.action_for_event(event)
	if action == "":
		return
	match action:
		DInput.ACT_TOGGLE_CALIBRATION:
			_toggle_calibration()
		DInput.ACT_TOGGLE_OVERLAY:
			if _overlay and _overlay.has_method("toggle"):
				_overlay.toggle()
		DInput.ACT_TOGGLE_NOCLIP:
			_set_noclip(not noclip)
		DInput.ACT_TOGGLE_FLY:
			_set_fly(not fly)
		DInput.ACT_PRINT_COORDS:
			_print_coords()
		DInput.ACT_TOGGLE_SPAWN:
			_toggle_spawn_menu()
		DInput.ACT_TOGGLE_FREECAM:
			_set_freecam(not freecam)
		DInput.ACT_UNSTUCK:
			_unstuck()
		DInput.ACT_SPEED_UP:
			_adjust_speed(1)
		DInput.ACT_SPEED_DOWN:
			_adjust_speed(-1)
		DInput.ACT_SPEED_RESET:
			_reset_speed()


# --------------------------------------------------------------------------- #
# Feature toggles (all gated by _features_ok)
# --------------------------------------------------------------------------- #


func _features_ok() -> bool:
	return enabled and movement_allowed and not network_detected


func _set_noclip(value: bool) -> void:
	if value and not _features_ok():
		_flash("Movement disabled (multiplayer/network).")
		return
	noclip = value
	if noclip:
		_refresh_player()
		_begin_control()
		_apply_noclip_collision(true)
		_flash("Noclip ON")
	else:
		_apply_noclip_collision(false)
		_flash("Noclip OFF")
		if not fly:
			_end_control()


func _set_fly(value: bool) -> void:
	if value and not _features_ok():
		_flash("Movement disabled (multiplayer/network).")
		return
	fly = value
	if fly:
		_refresh_player()
		_begin_control()
		_flash("Fly ON")
	else:
		_flash("Fly OFF")
		if not noclip:
			_end_control()


func _begin_control() -> void:
	var body := _player_spatial()
	if body != null:
		_ctrl_pos = body.global_position
		_ctrl_active = true


func _end_control() -> void:
	_ctrl_active = false


func _apply_noclip_collision(disable: bool) -> void:
	var body := _player_collision_object()
	if body == null:
		return
	if disable:
		if not _collision_saved:
			_orig_collision_layer = body.collision_layer
			_orig_collision_mask = body.collision_mask
			_collision_saved = true
		body.collision_layer = 0
		# Grounded noclip: collide ONLY with our follower floor (pass through all
		# real geometry, but stay "on the floor" so the phone can be opened).
		if _noclip_grounded and _setup_noclip_floor():
			body.collision_mask = NC_FLOOR_BIT
		else:
			body.collision_mask = 0  # classic noclip (no grounding)
	else:
		if _collision_saved:
			body.collision_layer = _orig_collision_layer
			body.collision_mask = _orig_collision_mask
			_collision_saved = false
		_remove_noclip_floor()


func _setup_noclip_floor() -> bool:
	_remove_noclip_floor()
	var body := _player_spatial()
	if body == null:
		return false
	# Attach in the player's own world (its parent), not current_scene (which some
	# games don't set), so the follower floor is in the same physics space.
	var parent: Node = body.get_parent()
	if parent == null and get_tree() != null:
		parent = get_tree().root
	if parent == null:
		return false
	# Feet = the LOWEST point of any of the player's collision shapes (robust to
	# multiple colliders), so the follower floor sits exactly under the feet.
	var shapes: Array = []
	_collect_collision_shapes(body, shapes)
	var feet_y := body.global_position.y
	var got := false
	for cs in shapes:
		if cs.shape == null:
			continue
		var half := 0.5
		var sh = cs.shape
		if sh is CapsuleShape3D:
			half = (sh as CapsuleShape3D).height * 0.5
		elif sh is CylinderShape3D:
			half = (sh as CylinderShape3D).height * 0.5
		elif sh is BoxShape3D:
			half = (sh as BoxShape3D).size.y * 0.5
		elif sh is SphereShape3D:
			half = (sh as SphereShape3D).radius
		var b: float = (cs as Node3D).global_position.y - half
		if not got or b < feet_y:
			feet_y = b
			got = true
	_nc_feet_offset = body.global_position.y - feet_y
	# Make the body stick to the follower floor (snap), so is_on_floor stays true.
	if "floor_snap_length" in body:
		_nc_orig_snap = float(body.get("floor_snap_length"))
		_nc_snap_saved = true
		body.set("floor_snap_length", 1.0)
	var floor_body := StaticBody3D.new()
	floor_body.name = "NopheniaNoclipFloor"
	floor_body.collision_layer = NC_FLOOR_BIT
	floor_body.collision_mask = 0
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(10.0, 1.0, 10.0)
	col.shape = box
	floor_body.add_child(col)
	parent.add_child(floor_body)
	_nc_floor = floor_body
	_update_noclip_floor()
	return true


func _collect_collision_shapes(node: Node, acc: Array) -> void:
	if node is CollisionShape3D:
		acc.append(node)
	for c in node.get_children():
		_collect_collision_shapes(c, acc)


func _update_noclip_floor() -> void:
	if _nc_floor == null or not is_instance_valid(_nc_floor):
		return
	var body := _player_spatial()
	if body == null:
		return
	var feet_y := body.global_position.y - _nc_feet_offset
	_nc_floor.global_position = Vector3(body.global_position.x, feet_y - 0.5, body.global_position.z)


func _remove_noclip_floor() -> void:
	if _nc_floor != null and is_instance_valid(_nc_floor):
		_nc_floor.queue_free()
	_nc_floor = null
	if _nc_snap_saved:
		var b := _player_spatial()
		if b != null and ("floor_snap_length" in b):
			b.set("floor_snap_length", _nc_orig_snap)
		_nc_snap_saved = false


func _set_freecam(value: bool) -> void:
	if value and not _features_ok():
		_flash("Freecam disabled (multiplayer/network).")
		return
	if value:
		_enable_freecam()
	else:
		_disable_freecam()


func _enable_freecam() -> void:
	if freecam:
		return
	var vp := get_viewport()
	if vp == null:
		return
	_prev_camera = vp.get_camera_3d()
	_freecam_node = Camera3D.new()
	get_tree().root.add_child(_freecam_node)
	if _prev_camera != null:
		_freecam_node.global_transform = _prev_camera.global_transform
		_freecam_yaw = _prev_camera.global_rotation.y
		_freecam_pitch = _prev_camera.global_rotation.x
	_freecam_node.current = true
	_prev_mouse_mode = Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	freecam = true
	_flash("Freecam ON (mouse look; press F5 to exit)")


func _disable_freecam() -> void:
	if not freecam:
		return
	freecam = false
	Input.mouse_mode = _prev_mouse_mode
	if _prev_camera != null and is_instance_valid(_prev_camera):
		_prev_camera.current = true
	if _freecam_node != null and is_instance_valid(_freecam_node):
		_freecam_node.queue_free()
	_freecam_node = null
	_flash("Freecam OFF")


func _freecam_mouse(event: InputEventMouseMotion) -> void:
	if _freecam_node == null:
		return
	var sensitivity := 0.003
	_freecam_yaw -= event.relative.x * sensitivity
	_freecam_pitch -= event.relative.y * sensitivity
	_freecam_pitch = clampf(_freecam_pitch, -1.5, 1.5)
	_freecam_node.global_rotation = Vector3(_freecam_pitch, _freecam_yaw, 0.0)


func _adjust_speed(direction: int) -> void:
	var step := 0.5 if speed_multiplier >= 1.0 else 0.1
	speed_multiplier = clampf(speed_multiplier + step * direction, SPEED_MIN, SPEED_MAX)
	_save_user_config()
	_flash("Speed x%0.2f" % speed_multiplier)


func _reset_speed() -> void:
	speed_multiplier = 1.0
	_save_user_config()
	_flash("Speed reset (x1.00)")


# --------------------------------------------------------------------------- #
# Coordinates / unstuck
# --------------------------------------------------------------------------- #


func _current_scene_name() -> String:
	var tree := get_tree()
	if tree != null and tree.current_scene != null:
		return String(tree.current_scene.name)
	return "(none)"


func _print_coords() -> void:
	_refresh_player()
	var body := _player_spatial()
	if body == null:
		print("[Debug Menu] No player Node3D found. Set 'player_node_path' in ", USER_CONFIG_PATH)
		_flash("No player found")
		return
	var p := body.global_position
	var r := body.global_rotation
	print("[Debug Menu] scene=%s pos=(%.3f, %.3f, %.3f) rot=(%.3f, %.3f, %.3f)" % [
		_current_scene_name(), p.x, p.y, p.z, r.x, r.y, r.z,
	])
	_flash("Coords: (%.1f, %.1f, %.1f)" % [p.x, p.y, p.z])


func _unstuck() -> void:
	if not _features_ok():
		_flash("Unstuck disabled (multiplayer/network).")
		return
	_refresh_player()
	var body := _player_spatial()
	if body == null:
		_flash("No player to unstuck")
		return
	body.global_position.y += 2.0
	_ctrl_pos = body.global_position
	if "velocity" in body:
		body.velocity = Vector3.ZERO
	_flash("Unstuck (nudged up 2m)")


func _toggle_spawn_menu() -> void:
	if _spawn_menu == null:
		return
	if _spawn_menu.has_method("toggle"):
		_spawn_menu.toggle()


# --------------------------------------------------------------------------- #
# Per-frame
# --------------------------------------------------------------------------- #


func _process(delta: float) -> void:
	_update_network_state()
	if _message_timer > 0.0:
		_message_timer -= delta
	_update_menu_mouse()
	_update_overlay()


func _update_network_state() -> void:
	var active := _is_network_active()
	if active and not network_detected:
		network_detected = true
		if noclip:
			_apply_noclip_collision(false)
		noclip = false
		fly = false
		_end_control()
		if freecam:
			_disable_freecam()
		if _spawn_menu and _spawn_menu.has_method("force_close"):
			_spawn_menu.force_close()
		_flash("Multiplayer/network detected: debug movement disabled.")
	network_detected = active


func _is_network_active() -> bool:
	var mp := multiplayer
	if mp == null or not mp.has_multiplayer_peer():
		return false
	var peer := mp.multiplayer_peer
	if peer == null or peer is OfflineMultiplayerPeer:
		return false
	if mp.get_peers().size() > 0:
		return true
	if mp.get_unique_id() != 1 and peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
		return true
	return false


func _physics_process(delta: float) -> void:
	# Only yield while the tree is actually PAUSED (a real pause freezes the game's
	# own player physics too, so noclip won't fall). We must NOT key off the phone
	# being "open": the phone UI lives in an always-rendering SubViewport, so it
	# reads as visible even when closed - yielding on that dropped noclip (collision
	# off) straight through the map.
	var tree := get_tree()
	var blocked: bool = tree != null and tree.paused
	if freecam and not blocked:
		_freecam_move(delta)
	if not _ctrl_active:
		return
	if blocked:
		var b := _player_spatial()
		if b != null:
			_ctrl_pos = b.global_position  # keep synced so there's no snap on resume
		return
	if not _features_ok():
		if _collision_saved:
			_apply_noclip_collision(false)
		_end_control()
		return
	if not (noclip or fly):
		return
	var body := _player_spatial()
	if body == null:
		_refresh_player()
		body = _player_spatial()
		if body == null:
			return
	var motion := _camera_relative_motion(delta)
	if fly and not noclip:
		motion *= FLY_SPEED_SCALE
	if noclip:
		_ctrl_pos += motion
		body.global_position = _ctrl_pos
		_update_noclip_floor()  # keep the invisible floor under the player (grounded noclip)
	elif fly:
		if body.has_method("move_and_collide"):
			body.global_position = _ctrl_pos
			body.call("move_and_collide", motion)
			_ctrl_pos = body.global_position
		else:
			_ctrl_pos += motion
			body.global_position = _ctrl_pos
	if "velocity" in body:
		if noclip and _nc_floor != null and is_instance_valid(_nc_floor):
			body.velocity = Vector3(0.0, -6.0, 0.0)  # press down onto the follower floor so is_on_floor registers
		else:
			body.velocity = Vector3.ZERO


func _camera_relative_motion(delta: float) -> Vector3:
	var axis := DInput.movement_axis()
	if axis == Vector3.ZERO:
		return Vector3.ZERO
	var basis := _active_basis()
	var forward := -basis.z
	var right := basis.x
	var dir := right * axis.x + Vector3.UP * axis.y + forward * axis.z
	if dir.length() > 1.0:
		dir = dir.normalized()
	return dir * BASE_SPEED * speed_multiplier * delta


func _active_basis() -> Basis:
	var vp := get_viewport()
	if vp != null:
		var cam := vp.get_camera_3d()
		if cam != null:
			return cam.global_transform.basis
	var body := _player_spatial()
	if body != null:
		return body.global_transform.basis
	return Basis.IDENTITY


func _freecam_move(delta: float) -> void:
	if _freecam_node == null:
		return
	var axis := DInput.movement_axis()
	var basis := _freecam_node.global_transform.basis
	var dir := basis.x * axis.x + Vector3.UP * axis.y + (-basis.z) * axis.z
	if dir.length() > 1.0:
		dir = dir.normalized()
	_freecam_node.global_position += dir * BASE_SPEED * speed_multiplier * delta


# --------------------------------------------------------------------------- #
# Public API used by the spawn menu (spawn_menu.gd)
# --------------------------------------------------------------------------- #


func is_features_allowed() -> bool:
	return _features_ok()


func is_spawn_allowed() -> bool:
	return spawn_allowed and _features_ok()


func get_spawn_transform() -> Transform3D:
	var vp := get_viewport()
	var cam: Camera3D = vp.get_camera_3d() if vp != null else null
	if cam != null:
		var t := cam.global_transform
		t.origin += -t.basis.z * 3.0
		return t
	var body := _player_spatial()
	if body != null:
		var t2 := body.global_transform
		t2.origin += -t2.basis.z * 3.0
		return t2
	return Transform3D.IDENTITY


func get_speed_multiplier() -> float:
	return speed_multiplier


func get_speed_min() -> float:
	return SPEED_MIN


func get_speed_max() -> float:
	return SPEED_MAX


func set_speed_multiplier(value: float) -> void:
	speed_multiplier = clampf(value, SPEED_MIN, SPEED_MAX)
	_save_user_config()


func adjust_speed(direction: int) -> void:
	_adjust_speed(direction)


func reset_speed() -> void:
	_reset_speed()


func is_menu_open() -> bool:
	return _spawn_menu != null and _spawn_menu.has_method("is_open") and _spawn_menu.is_open()


func spawn_scene(res_path: String) -> String:
	if not is_spawn_allowed():
		return "Spawning blocked (multiplayer/network)."
	var res := load(res_path)
	if res == null or not (res is PackedScene):
		return "Could not load as a scene: %s" % res_path
	var inst: Node = (res as PackedScene).instantiate()
	if not (inst is Node3D):
		inst.queue_free()
		return "Skipped (not a 3D scene): %s" % res_path
	var parent := get_tree().current_scene
	if parent == null:
		inst.queue_free()
		return "No current scene to spawn into."
	parent.add_child(inst)
	(inst as Node3D).global_transform = get_spawn_transform()
	_flash("Spawned %s" % res_path.get_file())
	return "Spawned: %s" % res_path.get_file()


# --------------------------------------------------------------------------- #
# Public API used by the phone Debug page (phone_menu.gd)
# --------------------------------------------------------------------------- #


func set_noclip(value: bool) -> void:
	_set_noclip(value)


func set_fly(value: bool) -> void:
	_set_fly(value)


func set_freecam(value: bool) -> void:
	_set_freecam(value)


func is_noclip() -> bool:
	return noclip


func is_fly() -> bool:
	return fly


func is_freecam() -> bool:
	return freecam


func do_unstuck() -> void:
	_unstuck()


func open_spawn_menu() -> void:
	_toggle_spawn_menu()


func print_coords_public() -> void:
	_print_coords()


func get_coords_text() -> String:
	var body := _player_spatial()
	if body == null:
		return "coords: (no player)"
	var p := body.global_position
	return "coords: (%.1f, %.1f, %.1f)  scene: %s" % [p.x, p.y, p.z, _current_scene_name()]


func has_flashlight_mod() -> bool:
	return _flashlight_mod() != null


func toggle_flashlight_calibration() -> void:
	_toggle_calibration()


# --------------------------------------------------------------------------- #
# Sightless Lite calibration tool (F8) - drives the separate Sightless Lite mod.
# NOTE: scale (+/-) was intentionally removed so +/- stay the speed keys.
# --------------------------------------------------------------------------- #


func _toggle_calibration() -> void:
	var fl = _flashlight_mod()
	if fl == null:
		_flash("Sightless Lite not installed - nothing to calibrate.")
		return
	_fl_calibrating = not _fl_calibrating
	if _fl_calibrating:
		if fl.has_method("set_on"):
			fl.set_on(true)
		_flash("Sightless Lite calibrate ON - arrows=pos, Shift+arrows=rot, R=re-aim, K=save, F8=exit")
	else:
		_flash("Sightless Lite calibrate OFF")


func _handle_calibration_key(event: InputEventKey) -> bool:
	var fl = _flashlight_mod()
	if fl == null:
		return false
	var shift := event.shift_pressed
	var dp := 0.02
	var dr := 5.0
	match event.keycode:
		KEY_LEFT:
			if shift: fl.cal_nudge_rot(Vector3(0.0, -dr, 0.0))
			else: fl.cal_nudge_pos(Vector3(-dp, 0.0, 0.0))
		KEY_RIGHT:
			if shift: fl.cal_nudge_rot(Vector3(0.0, dr, 0.0))
			else: fl.cal_nudge_pos(Vector3(dp, 0.0, 0.0))
		KEY_UP:
			if shift: fl.cal_nudge_rot(Vector3(-dr, 0.0, 0.0))
			else: fl.cal_nudge_pos(Vector3(0.0, dp, 0.0))
		KEY_DOWN:
			if shift: fl.cal_nudge_rot(Vector3(dr, 0.0, 0.0))
			else: fl.cal_nudge_pos(Vector3(0.0, -dp, 0.0))
		KEY_PAGEUP:
			if shift: fl.cal_nudge_rot(Vector3(0.0, 0.0, -dr))
			else: fl.cal_nudge_pos(Vector3(0.0, 0.0, -dp))
		KEY_PAGEDOWN:
			if shift: fl.cal_nudge_rot(Vector3(0.0, 0.0, dr))
			else: fl.cal_nudge_pos(Vector3(0.0, 0.0, dp))
		KEY_R:
			fl.cal_reaim()
			_flash("Flashlight re-aimed")
			return true
		KEY_K:
			fl.cal_save()
			_flash("Sightless Lite config saved")
			return true
		_:
			return false
	_flash("Sightless Lite calibrated (see overlay)")
	return true


func _vec_s(v: Vector3) -> String:
	return "(%.2f, %.2f, %.2f)" % [v.x, v.y, v.z]


func _flashlight_debug_text() -> String:
	var fl = _flashlight_mod()
	if fl == null:
		return ""
	var fl_on: bool = fl.has_method("is_on") and fl.is_on()
	if not fl_on and not _fl_calibrating:
		return ""
	var st: Dictionary = fl.cal_state() if fl.has_method("cal_state") else {}
	var lines: Array[String] = []
	lines.append("SL attach=%s  bone=%s  on=%s" % [str(st.get("attach", "-")), str(st.get("bone", "-")), str(st.get("on", false))])
	lines.append("SL pos=%s rot=%s x%.2f" % [_vec_s(st.get("pos", Vector3.ZERO)), _vec_s(st.get("rot", Vector3.ZERO)), float(st.get("scale", 1.0))])
	if _fl_calibrating:
		lines.append("CALIBRATE: arrows pos | Shift+arrows rot | R re-aim | K save | F8 exit")
	return "\n".join(lines)


func _update_menu_mouse() -> void:
	if is_menu_open():
		if Input.mouse_mode != Input.MOUSE_MODE_VISIBLE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# --------------------------------------------------------------------------- #
# Overlay glue / misc
# --------------------------------------------------------------------------- #


func _flash(message: String) -> void:
	_last_message = message
	_message_timer = 3.0
	print("[Debug Menu] ", message)


func _update_overlay() -> void:
	if _overlay == null or not _overlay.has_method("update_state"):
		return
	var body := _player_spatial()
	var pos := body.global_position if body != null else Vector3.ZERO
	var fl = _flashlight_mod()
	var fl_on: bool = fl != null and fl.has_method("is_on") and fl.is_on()
	_overlay.update_state({
		"enabled": enabled,
		"movement_allowed": movement_allowed,
		"network_detected": network_detected,
		"noclip": noclip,
		"fly": fly,
		"freecam": freecam,
		"speed": speed_multiplier,
		"pos": pos,
		"has_player": body != null,
		"scene": _current_scene_name(),
		"flashlight": fl_on,
		"flashlight_present": fl != null,
		"flashlight_debug": _flashlight_debug_text(),
		"message": _last_message if _message_timer > 0.0 else "",
	})


func _print_banner() -> void:
	print("=".repeat(60))
	print("[Debug Menu] loaded.")
	print("  F2 overlay | F3 noclip | F4 fly | F5 freecam")
	print("  F6 spawn menu | F7 unstuck | F8 Sightless Lite calibrate")
	print("  F10 phone Debug page (also opens from the in-game phone)")
	print("  =/- speed | 0 reset | WASD+Space/Shift move. F1 = Sightless Lite.")
	if not movement_allowed:
		print("  NOTE: multiplayer content detected at patch time -> movement disabled.")
	print("=".repeat(60))
