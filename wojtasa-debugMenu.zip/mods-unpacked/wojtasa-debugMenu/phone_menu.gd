# phone_menu.gd - integrates the debug menu into nophenia's in-world phone UI.
#
# The game shows an in-world phone with sections (Camera / Display / General /
# Transitional / Wallpaper). This adds a "Debug" entry/page that opens the debug
# controls, WITHOUT patching the game's compiled scripts or touching save data.
#
# Strategy (config: debug_phone_mode = auto|native|overlay|off):
#   * discover phone-like nodes in the live scene tree (logged for tuning),
#   * detect when the phone is open (a discovered node becomes visible),
#   * NATIVE: best-effort add a "Debug" entry Control into the phone's menu list,
#   * OVERLAY: draw a phone-styled "Debug" tab + page shown only while the phone
#     is open (the reliable fallback when native injection isn't safe/possible).
#
# The Debug PAGE is always openable with F10 as a guaranteed fallback, and (when
# the phone is detected open) with the configurable contextual key (default D),
# or by clicking the on-screen "Debug" entry. It drives the debug_tools
# controller's public API; Sightless Lite controls appear only if that mod is
# installed. Nothing here steals input except while the Debug page is open.

extends CanvasLayer

const PHONE_NAME_HINTS := ["phone", "keitai", "mobile", "cell", "smartphone", "handy", "device"]
const MENU_NAME_HINTS := ["menu", "settings", "setting", "list", "item", "option", "entry",
	"row", "apps", "app", "home", "screen", "page", "tab", "ui"]
# Known nophenia phone entries as [match_pattern, canonical_word] - the strongest
# "this is the phone settings list" signal. Detection credits the closest shared
# ancestor of several DISTINCT canonical words (see _scan). Variants collapse to
# one canonical so e.g. "End Program"/"endprogram" don't double-count.
const ENTRY_PATTERNS := [
	["camera", "camera"], ["display", "display"], ["general", "general"],
	["audio", "audio"], ["wallpaper", "wallpaper"], ["info", "info"],
	["kitty", "kitty"], ["forget", "forget"], ["transitional", "transitional"],
	["end program", "endprog"], ["endprogram", "endprog"], ["end_program", "endprog"],
]
const ANCESTOR_DEPTH := 6     # how far up to credit a shared container
const SCAN_NODE_BUDGET := 8000
const SCAN_MAX_DEPTH := 64
const REDISCOVER_FOUND := 2.0
const REDISCOVER_LOST := 0.5
# nophenia's own phone option-row scene (each Camera/Display/… row is an instance
# of this). We inject a real Debug row by duplicating an existing option button,
# or by instancing this if the list has no children to clone.
const OPTION_SCENE := "res://resource/pause_menu_phone_option.tscn"

var _controller = null
var _cfg := {
	"integration": true,
	"mode": "auto",
	"native_injection": true,
	"overlay_fallback": true,
	"entry_label": "Debug",
	"diagnostics": false,
	"open_key": "D",
	"force_native": false,
	"menu_container_path": "",      # explicit options-container override (advanced)
	"insert_before_text": "End Program",
	"insert_after_text": "Kitty",
}

# discovery / detection
var _phone_root: Node = null        # node whose visibility ~= "phone is open"
var _native_target: Node = null     # menu container we could inject a Debug entry into
var _phone_open := false
var _rediscover_timer := 0.0
var _last_detect_log := ""

# native injection
var _native_entry: Control = null   # the "Debug" entry we added into the game's menu
var _last_inject_target_id := 0

# overlay UI
var _entry_panel: PanelContainer = null  # phone-styled "Debug" tab shown while phone open
var _page: PanelContainer = null         # the Debug page
var _page_open := false
var _nav: Array = []                     # [{button, activate, left, right, refresh}]
var _sel := 0
var _open_keycode := KEY_D

# in-phone Debug page (rendered INSIDE the phone's SubViewport menu, opened by the
# native row's own navigation - this is the "UI is in the phone" path)
var _phone_page: Control = null
var _phone_options_page: Node = null     # the game's "options" list page (to restore on Back)
var _hidden_siblings: Array = []         # phone menu nodes we hid while the Debug page is up
var _phone_nav: Array = []
var _icon_tex: Texture2D = null
var _font_main = null                     # menu_large.ttf (the phone's option-title font)
var _font_small = null                    # menu_maru.ttf  (the phone's small-label font)
var _sb_empty: StyleBox = null            # transparent (resting buttons)
var _sb_hover: StyleBox = null            # mouse-over highlight
var _sb_pressed: StyleBox = null          # click highlight


# --------------------------------------------------------------------------- #
# Setup
# --------------------------------------------------------------------------- #


func _ready() -> void:
	layer = 135  # above the floating overlay (128) and spawn menu (130)
	process_mode = Node.PROCESS_MODE_ALWAYS


# Called by debug_tools right after add_child() (so it runs AFTER _ready); this
# is where the UI is built, so the (post-default) config is already applied.
func setup(controller: Node, cfg: Dictionary) -> void:
	_controller = controller
	for k in cfg.keys():
		_cfg[k] = cfg[k]
	_open_keycode = _keycode_from_string(String(_cfg.get("open_key", "D")))
	_build_entry()
	_build_page()
	_set_entry_visible(false)
	_set_page_visible(false)
	if not bool(_cfg.get("integration", true)) or String(_cfg.get("mode", "auto")) == "off":
		print("[Debug Menu] integration disabled (mode=", _cfg.get("mode", "auto"), ").")
	else:
		print("[Debug Menu] integration on (mode=", _cfg.get("mode", "auto"),
			"). Open the Debug page with F10, or from the in-game phone.")


# --------------------------------------------------------------------------- #
# Per-frame
# --------------------------------------------------------------------------- #


func _process(delta: float) -> void:
	if not bool(_cfg.get("integration", true)):
		return
	var mode := String(_cfg.get("mode", "auto"))
	if mode == "off":
		return

	_rediscover_timer -= delta
	if _phone_root == null or not is_instance_valid(_phone_root) or _rediscover_timer <= 0.0:
		var found := _phone_root != null and is_instance_valid(_phone_root)
		_rediscover_timer = REDISCOVER_FOUND if found else REDISCOVER_LOST
		_discover_phone()

	_phone_open = _phone_root != null and is_instance_valid(_phone_root) and _node_visible(_phone_root)

	# Native injection (best-effort): attempt once per distinct target node.
	var entry_ok := _native_entry != null and is_instance_valid(_native_entry)
	if (mode == "native" or mode == "auto") and bool(_cfg.get("native_injection", true)):
		var tgt_ok := _native_target != null and is_instance_valid(_native_target)
		if tgt_ok and not entry_ok and _native_target.get_instance_id() != _last_inject_target_id:
			_last_inject_target_id = _native_target.get_instance_id()
			_try_native_inject()
			entry_ok = _native_entry != null and is_instance_valid(_native_entry)

	# Overlay "Debug" tab: shown only while the phone is open and there's no working
	# native entry (in overlay mode, always; in native mode only if fallback allowed).
	var want_overlay_entry := _phone_open and not entry_ok
	if mode == "native":
		want_overlay_entry = _phone_open and not entry_ok and bool(_cfg.get("overlay_fallback", true))
	if bool(_cfg.get("force_native", false)):
		want_overlay_entry = false  # only the real native row; no phone-styled overlay tab
	if want_overlay_entry and not _page_open:
		_position_entry()
	_set_entry_visible(want_overlay_entry and not _page_open)

	# Keep the floating fallback page's live values updated while open.
	if _page_open:
		_refresh_page()
		if Input.mouse_mode != Input.MOUSE_MODE_VISIBLE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	# Keep the in-phone Debug page's live values updated while it's shown.
	if _phone_page != null and is_instance_valid(_phone_page) and _phone_page.visible:
		_refresh_phone_page()


# --------------------------------------------------------------------------- #
# Phone discovery + diagnostics
# --------------------------------------------------------------------------- #


func _discover_phone() -> void:
	var tree := get_tree()
	if tree == null or tree.root == null:
		return

	# Preferred: nophenia's real phone options list = the container holding the
	# most "option_*" rows (Camera/Display/…/Forget/End Program). Inject there.
	var oc := _find_options_container()
	if oc != null and is_instance_valid(oc):
		_native_target = oc
		_phone_root = oc
		var detect_oc := String(oc.get_path())
		if detect_oc != _last_detect_log:
			_last_detect_log = detect_oc
			print("[Debug Menu] phone options list found: ", detect_oc,
				" (", oc.get_class(), ", ", oc.get_child_count(), " rows) -> native injection target")
		return

	var phone_cands: Array = []     # [{node, score}] - name-based fallback
	var ancestors := {}             # id -> {node, words:{set}, mindist, control}
	var interesting: Array = []     # ignored here (used by the diagnostics dump)
	var counter := [0]
	_scan(tree.root, 0, phone_cands, ancestors, interesting, counter)

	# The phone's menu list = the CLOSEST shared ancestor of several known phone
	# entries (Camera/Display/Audio/Kitty/Forget/…). Each entry's own wrapper only
	# sees one word; the real list sees many, so it wins on distinct-word count,
	# then on proximity (smaller distance = tighter container).
	var best_menu: Node = null      # a Control list we can inject into
	var best_menu_score := -1
	var best_anchor: Node = null    # open-detection anchor (any node)
	var best_anchor_score := -1
	var best_words := 0
	for id in ancestors:
		var a: Dictionary = ancestors[id]
		if not is_instance_valid(a["node"]):
			continue
		var words: int = (a["words"] as Dictionary).size()
		if words < 2:
			continue
		var sc: int = words * 100 - int(a["mindist"])
		if sc > best_anchor_score:
			best_anchor_score = sc
			best_anchor = a["node"]
		if bool(a["control"]) and sc > best_menu_score:
			best_menu_score = sc
			best_menu = a["node"]
		if words > best_words:
			best_words = words

	phone_cands.sort_custom(func(a, b): return int(a["score"]) > int(b["score"]))
	var best_phone: Node = null
	for c in phone_cands:
		if is_instance_valid(c["node"]):
			best_phone = c["node"]
			break

	_native_target = best_menu  # may be null if no Control list was found
	if best_anchor != null:
		_phone_root = best_anchor
	elif best_phone != null:
		_phone_root = best_phone
	else:
		_phone_root = null

	var detect := "(none)" if _phone_root == null else String(_phone_root.get_path())
	if detect != _last_detect_log:
		_last_detect_log = detect
		print("[Debug Menu] phone UI detected: ", detect,
			"  native_target=", "(none)" if _native_target == null else String(_native_target.get_path()))


func _scan(node: Node, depth: int, phone_cands: Array, ancestors: Dictionary, interesting: Array, counter: Array) -> void:
	if node == null or depth > SCAN_MAX_DEPTH or counter[0] > SCAN_NODE_BUDGET:
		return
	counter[0] += 1

	var lname := String(node.name).to_lower()
	var score := 0
	for h in PHONE_NAME_HINTS:
		if lname.find(h) != -1:
			score += 10
	for h in MENU_NAME_HINTS:
		if lname.find(h) != -1:
			score += 2
	if node is SubViewport:
		score += 4
	if score >= 10:
		phone_cands.append({"node": node, "score": score})

	# Entry signal: this node's NAME or TEXT matches a known phone entry word.
	var w := _entry_word(node, lname)
	if w != "":
		if interesting.size() < 120:
			interesting.append({"node": node, "why": "entry:" + w})
		var anc := node.get_parent()
		var d := 1
		while anc != null and d <= ANCESTOR_DEPTH:
			var aid := anc.get_instance_id()
			if not ancestors.has(aid):
				ancestors[aid] = {"node": anc, "words": {}, "mindist": d, "control": anc is Control}
			(ancestors[aid]["words"] as Dictionary)[w] = true
			if d < int(ancestors[aid]["mindist"]):
				ancestors[aid]["mindist"] = d
			anc = anc.get_parent()
			d += 1
	elif score >= 10 and interesting.size() < 120:
		interesting.append({"node": node, "why": "name"})

	for child in node.get_children():
		_scan(child, depth + 1, phone_cands, ancestors, interesting, counter)
		if counter[0] > SCAN_NODE_BUDGET:
			return


# Returns the canonical phone-entry word this node matches (name or text), or "".
func _entry_word(node: Node, lname: String) -> String:
	for pair in ENTRY_PATTERNS:
		var pat: String = pair[0]
		if lname.find(pat) != -1 or lname.find(pat.replace(" ", "")) != -1 or lname.find(pat.replace(" ", "_")) != -1:
			return pair[1]
	var t := _node_text(node)
	if t != "":
		var tl := t.to_lower()
		for pair in ENTRY_PATTERNS:
			if tl.find(pair[0]) != -1:
				return pair[1]
	return ""


func _node_text(node: Node) -> String:
	if node is Label or node is Button or node is RichTextLabel or node is LineEdit:
		return String(node.get("text"))
	if "text" in node:
		return String(node.get("text"))
	return ""


func _under_viewport(node: Node) -> bool:
	var anc := node.get_parent()
	while anc != null:
		if anc is SubViewport:
			return true
		anc = anc.get_parent()
	return false


# The phone's main options list = the Control whose direct children are mostly
# named "option_*"; the main list also has option_exitgame/new_save/cat/freecam,
# which scores it above the per-page sub-lists (display/volume).
func _find_options_container() -> Node:
	var ov := String(_cfg.get("menu_container_path", ""))
	if ov != "":
		var n := get_node_or_null(NodePath(ov))
		if n != null:
			return n
	var cands: Array = []
	var counter := [0]
	_scan_containers(get_tree().root, 0, cands, counter)
	var best: Node = null
	var best_score := -1
	for c in cands:
		if int(c["score"]) > best_score and is_instance_valid(c["node"]):
			best_score = int(c["score"])
			best = c["node"]
	return best


func _scan_containers(node: Node, depth: int, cands: Array, counter: Array) -> void:
	if node == null or depth > SCAN_MAX_DEPTH or counter[0] > SCAN_NODE_BUDGET:
		return
	counter[0] += 1
	var optc := 0
	var bonus := 0
	for ch in node.get_children():
		var nm := String(ch.name).to_lower()
		if nm.begins_with("option"):
			optc += 1
			if nm.find("exit") != -1 or nm.find("new_save") != -1 or nm.find("cat") != -1 \
					or nm.find("freecam") != -1 or nm.find("multiplayer") != -1:
				bonus += 3
	if optc >= 3 and node is Control:
		cands.append({"node": node, "score": optc + bonus})
	for ch in node.get_children():
		_scan_containers(ch, depth + 1, cands, counter)
		if counter[0] > SCAN_NODE_BUDGET:
			return


func _option_title(node: Node) -> String:
	var lbl := node.find_child("display_title", true, false)
	if lbl != null and ("text" in lbl):
		return String(lbl.get("text"))
	return ""


func _node_visible(n: Node) -> bool:
	if n == null or not is_instance_valid(n):
		return false
	if n.has_method("is_visible_in_tree"):
		return n.is_visible_in_tree()
	if "visible" in n:
		return bool(n.get("visible"))
	return true


# --------------------------------------------------------------------------- #
# Native injection (best-effort, reversible - only adds our own child node)
# --------------------------------------------------------------------------- #


func _try_native_inject() -> void:
	var container := _native_target
	if container == null or not is_instance_valid(container):
		return
	if not (container is Control):
		print("[Debug Menu] native injection skipped: container ", container.get_path(),
			" is ", container.get_class(), " (not a Control) -> overlay fallback.")
		return

	# Make sure the in-phone Debug PAGE exists (rendered inside the phone menu).
	var menu := _find_phone_menu(container)
	if menu != null and (_phone_page == null or not is_instance_valid(_phone_page)):
		_build_phone_page(menu)

	# Choose a NAVIGATING option as the template (one with a `_screen` export, a
	# real icon and the row script), and an anchor to insert before.
	var template: Node = null
	var anchor: Node = null
	var ibefore := String(_cfg.get("insert_before_text", "End Program")).to_lower()
	for ch in container.get_children():
		if not (ch is Control):
			continue
		if String(ch.name) == "NopheniaDebugOption":
			_native_entry = ch  # already present (re-acquire ref)
			return
		var nm := String(ch.name).to_lower()
		if nm.begins_with("option"):
			if template == null and ("_screen" in ch):
				template = ch
			if nm.find("info") != -1 and ("_screen" in ch):
				template = ch  # the Info row is a clean nav row to clone
			var t := _option_title(ch).to_lower()
			if anchor == null and ibefore != "" and (t == ibefore or nm.find("exit") != -1):
				anchor = ch
	if template == null:  # fall back to any option row
		for ch in container.get_children():
			if ch is Control and String(ch.name).to_lower().begins_with("option"):
				template = ch
				break
	if template == null:
		print("[Debug Menu] native injection skipped: no option row to clone in ", container.get_path())
		return

	var row := (template as Control).duplicate() as Control
	if row == null:
		return
	# Keep the row's script so it highlights and behaves like the native rows, and
	# give it unique materials so its hover shader is independent of the source row.
	row.name = "NopheniaDebugOption"
	_make_materials_unique(row)
	# Properties the row script reads in _ready: title key, icon, and the page it
	# navigates to - which we repoint at OUR in-phone Debug page.
	if "text" in row:
		row.set("text", String(_cfg.get("entry_label", "Debug")))
	var tex := _load_icon_texture()
	if tex != null and ("icon" in row):
		row.set("icon", tex)
	if _phone_page != null and is_instance_valid(_phone_page) and ("_screen" in row):
		row.set("_screen", _phone_page)
	container.add_child(row)   # _ready runs here, configuring from the props above
	if anchor != null and is_instance_valid(anchor):
		container.move_child(row, anchor.get_index())
	# Override the visible title + icon directly (in case the script blanked them),
	# and tint the Debug label a darkish terminal green.
	var lbl := row.find_child("display_title", true, false)
	if lbl is Control:
		if "text" in lbl:
			lbl.set("text", String(_cfg.get("entry_label", "Debug")))
		(lbl as Control).add_theme_color_override("font_color", Color(0.16, 0.55, 0.20))
	if tex != null:
		var pv := row.find_child("preview_tex", true, false)
		if pv != null and ("texture" in pv):
			pv.set("texture", tex)
	# Backup activation: also open our in-phone page on press (covers the case the
	# game doesn't navigate via _screen). pressed only fires on real activation, so
	# it does NOT auto-open while scrolling/focusing.
	if row.has_signal("pressed"):
		row.connect("pressed", Callable(self, "_show_phone_debug_page"))
	_native_entry = row
	print("[Debug Menu] NATIVE Debug row injected (template=", template.name,
		", in-phone page=", _phone_page != null and is_instance_valid(_phone_page),
		", icon=", tex != null, ", index=", row.get_index(), ").")


func _make_materials_unique(node: Node) -> void:
	if node is CanvasItem:
		var m: Material = (node as CanvasItem).material
		if m != null:
			(node as CanvasItem).material = m.duplicate()
	for c in node.get_children():
		_make_materials_unique(c)


func _load_icon_texture() -> Texture2D:
	if _icon_tex != null:
		return _icon_tex
	var p := "res://nophenia_debug/assets/debug_icon.png"
	if not FileAccess.file_exists(p):
		return null
	var bytes := FileAccess.get_file_as_bytes(p)
	if bytes.is_empty():
		return null
	var img := Image.new()
	if img.load_png_from_buffer(bytes) != OK:
		return null
	_icon_tex = ImageTexture.create_from_image(img)
	return _icon_tex


# --------------------------------------------------------------------------- #
# In-phone Debug page (a Control added under the phone's `menu`, shown by the
# native row's navigation so it renders on the actual phone screen).
# --------------------------------------------------------------------------- #


func _find_phone_menu(container: Node) -> Node:
	var n := container.get_parent()
	var hops := 0
	while n != null and hops < 8:
		if String(n.name) == "menu":
			return n
		n = n.get_parent()
		hops += 1
	return null


func _ensure_fonts() -> void:
	if _font_main == null:
		var f = load("res://resource/font/menu_large.ttf")
		if f != null:
			_font_main = f
	if _font_small == null:
		var f2 = load("res://resource/font/menu_maru.ttf")
		if f2 != null:
			_font_small = f2


# Style a Label/Button to match the phone's native option text (crisp pixel font
# + black outline + white), instead of the default blurry project font.
func _style_text(node: Control, size: int, small := false) -> void:
	var f = _font_small if small else _font_main
	if f != null:
		node.add_theme_font_override("font", f)
	node.add_theme_font_size_override("font_size", size)
	node.add_theme_color_override("font_color", Color(0.38, 0.88, 0.45))  # terminal green
	node.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	node.add_theme_constant_override("outline_size", 2)
	# Override the phone theme's button styles on our Debug-page buttons only:
	# transparent at rest, a clean green highlight on
	# hover/press. No other phone tab is touched.
	if node is BaseButton:
		if _sb_empty == null:
			_sb_empty = StyleBoxEmpty.new()
			var hov := StyleBoxFlat.new()
			hov.bg_color = Color(0.20, 0.60, 0.25, 0.35)
			hov.set_corner_radius_all(2)
			_sb_hover = hov
			var prs := StyleBoxFlat.new()
			prs.bg_color = Color(0.25, 0.72, 0.32, 0.55)
			prs.set_corner_radius_all(2)
			_sb_pressed = prs
		node.add_theme_stylebox_override("normal", _sb_empty)
		node.add_theme_stylebox_override("focus", _sb_empty)
		node.add_theme_stylebox_override("disabled", _sb_empty)
		node.add_theme_stylebox_override("hover", _sb_hover)
		node.add_theme_stylebox_override("hover_pressed", _sb_pressed)
		node.add_theme_stylebox_override("pressed", _sb_pressed)


func _build_phone_page(menu: Node) -> void:
	_ensure_fonts()
	var page := Control.new()
	page.name = "NopheniaDebugPage"
	page.set_anchors_preset(Control.PRESET_FULL_RECT)
	page.visible = false
	page.z_index = 200  # draw above the phone's wallpaper / chrome
	var th = load("res://resource/pause_menu_phone.tres")
	if th != null and th is Theme:
		page.theme = th

	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.0, 0.0, 0.0, 1.0)  # opaque background for the Debug page
	page.add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 4)
	margin.add_theme_constant_override("margin_right", 4)
	margin.add_theme_constant_override("margin_top", 3)
	margin.add_theme_constant_override("margin_bottom", 3)
	page.add_child(margin)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 1)
	margin.add_child(vb)

	var title := Label.new()
	title.text = "DEBUG"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_text(title, 17)
	vb.add_child(title)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 1)
	scroll.add_child(list)

	_phone_nav.clear()
	_add_phone_toggle(list, "noclip", "Noclip")    # native-style on/off checkbox
	_add_phone_toggle(list, "fly", "Fly")
	_add_phone_toggle(list, "freecam", "Freecam")
	_add_phone_speed_slider(list)                  # one slider instead of -/+ buttons
	_add_phone_row(list, "unstuck", "Unstuck", Color(0.88, 0.18, 0.22))
	_add_phone_row(list, "spawn", "Spawn menu")
	if _ctrl_call_bool("has_flashlight_mod"):
		_add_phone_row(list, "flcalib", "Sightless Lite cal.")

	var back := Button.new()
	back.text = "Back"
	back.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	back.size_flags_horizontal = Control.SIZE_SHRINK_END  # sit on the right side
	back.focus_mode = Control.FOCUS_NONE
	_style_text(back, 17)
	back.pressed.connect(_hide_phone_debug_page)
	vb.add_child(back)

	menu.add_child(page)
	_phone_page = page
	_phone_options_page = menu.get_node_or_null("options")  # to restore on Back
	_refresh_phone_page()


func _add_phone_row(list: VBoxContainer, kind: String, label: String, color := Color(1, 1, 1, 1)) -> void:
	var b := Button.new()
	b.text = label
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	_style_text(b, 17)
	if color != Color(1, 1, 1, 1):
		b.add_theme_color_override("font_color", color)
	b.pressed.connect(_activate_kind.bind(kind))
	list.add_child(b)
	_phone_nav.append({"button": b, "kind": kind, "label": label})


# A native-style on/off row: a CheckBox (the phone theme gives it the round
# checked/unchecked indicator the other phone options use) plus the label.
func _add_phone_toggle(list: VBoxContainer, kind: String, label: String) -> void:
	var cb := CheckBox.new()
	cb.text = label
	cb.focus_mode = Control.FOCUS_NONE
	_style_text(cb, 17)
	cb.set_pressed_no_signal(_row_toggle_state(kind) == 1)
	cb.toggled.connect(_set_toggle_kind.bind(kind))
	list.add_child(cb)
	_phone_nav.append({"button": cb, "kind": kind, "label": label, "check": true})


func _set_toggle_kind(pressed: bool, kind: String) -> void:
	match kind:
		"noclip":
			_ctrl_call("set_noclip", [pressed])
		"fly":
			_ctrl_call("set_fly", [pressed])
		"freecam":
			_ctrl_call("set_freecam", [pressed])
	_refresh_page()
	_refresh_phone_page()


# A single speed slider built to match the phone's OWN brightness/camera sliders:
# the same phone_ui.png track/fill styleboxes and ◄ ► arrow textures, with the
# default white grabber circle removed (an empty placeholder), so it looks native.
func _add_phone_speed_slider(list: VBoxContainer) -> void:
	var lbl := Label.new()
	lbl.name = "PhoneSpeedLabel"
	_style_text(lbl, 15)
	list.add_child(lbl)

	var ph: Texture2D = load("res://texture/phone_ui.png")
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 3)

	var left := TextureRect.new()
	left.stretch_mode = TextureRect.STRETCH_KEEP
	left.flip_h = true
	if ph != null:
		left.texture = _atlas(ph, Rect2(71, 0, 6, 11))
	row.add_child(left)

	var sl := HSlider.new()
	sl.name = "PhoneSpeedSlider"
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.min_value = _ctrl_call_num("get_speed_min", 0.1)
	sl.max_value = _ctrl_call_num("get_speed_max", 20.0)
	sl.step = 0.1
	sl.custom_minimum_size = Vector2(0, 12)
	sl.focus_mode = Control.FOCUS_NONE
	var empty := PlaceholderTexture2D.new()
	sl.add_theme_icon_override("grabber", empty)            # kill the white circle
	sl.add_theme_icon_override("grabber_highlight", empty)
	sl.add_theme_icon_override("grabber_disabled", empty)
	if ph != null:
		sl.add_theme_stylebox_override("slider", _sbtex(ph, Rect2(135, 52, 13, 10), 6.0, 4.0))
		sl.add_theme_stylebox_override("grabber_area", _sbtex(ph, Rect2(135, 41, 13, 10)))
		sl.add_theme_stylebox_override("grabber_area_highlight", _sbtex(ph, Rect2(135, 41, 13, 10)))
	sl.set_value_no_signal(_ctrl_call_num("get_speed_multiplier", 1.0))
	sl.value_changed.connect(_on_phone_speed_changed)

	var val := Label.new()
	val.name = "PhoneSpeedValue"
	val.set_anchors_preset(Control.PRESET_FULL_RECT)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	val.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_text(val, 12)
	sl.add_child(val)
	row.add_child(sl)

	var right := TextureRect.new()
	right.stretch_mode = TextureRect.STRETCH_KEEP
	if ph != null:
		right.texture = _atlas(ph, Rect2(71, 0, 6, 11))
	row.add_child(right)

	list.add_child(row)


func _atlas(tex: Texture2D, region: Rect2) -> AtlasTexture:
	var a := AtlasTexture.new()
	a.atlas = tex
	a.region = region
	return a


func _sbtex(tex: Texture2D, region: Rect2, cm_top := 0.0, cm_bottom := 0.0) -> StyleBoxTexture:
	var s := StyleBoxTexture.new()
	s.texture = tex
	s.region_rect = region
	s.texture_margin_left = 1.0
	s.texture_margin_top = 1.0
	s.texture_margin_right = 1.0
	s.texture_margin_bottom = 1.0
	s.axis_stretch_horizontal = 1  # TILE, matching the game's slider styleboxes
	s.axis_stretch_vertical = 1
	if cm_top > 0.0:
		s.content_margin_top = cm_top
	if cm_bottom > 0.0:
		s.content_margin_bottom = cm_bottom
	return s


func _on_phone_speed_changed(v: float) -> void:
	_ctrl_call("set_speed_multiplier", [v])
	_refresh_phone_page()
	_refresh_page()


func _refresh_phone_page() -> void:
	if _phone_page == null or not is_instance_valid(_phone_page):
		return
	for e in _phone_nav:
		if bool(e.get("check", false)):
			var st := _row_toggle_state(String(e["kind"]))
			var cb = e["button"]
			if cb is CheckBox and st >= 0:
				(cb as CheckBox).set_pressed_no_signal(st == 1)
	var spd := _ctrl_call_num("get_speed_multiplier", 1.0)
	var sl := _phone_page.find_child("PhoneSpeedSlider", true, false)
	if sl is HSlider:
		(sl as HSlider).set_value_no_signal(spd)
	var lbl := _phone_page.find_child("PhoneSpeedLabel", true, false)
	if lbl is Label:
		(lbl as Label).text = "Speed: x%0.2f" % spd
	var val := _phone_page.find_child("PhoneSpeedValue", true, false)
	if val is Label:
		(val as Label).text = "x%0.1f" % spd


func _show_phone_debug_page() -> void:
	if _phone_page == null or not is_instance_valid(_phone_page):
		_open_page()  # fall back to the floating page if the in-phone one is gone
		return
	var p := _phone_page.get_parent()
	if p != null:
		p.move_child(_phone_page, p.get_child_count() - 1)  # draw on top of the other pages
		# Hide EVERY other page/overlay under `menu` (home/options/selection bars/...)
		# so nothing shows through or over our Debug page. Restored on Back.
		_hidden_siblings.clear()
		for child in p.get_children():
			if child != _phone_page and ("visible" in child) and bool(child.get("visible")):
				_hidden_siblings.append(child)
				child.set("visible", false)
	_phone_page.visible = true
	_refresh_phone_page()


func _hide_phone_debug_page() -> void:
	if _phone_page != null and is_instance_valid(_phone_page):
		_phone_page.visible = false
	# Restore the phone pages/overlays we hid while our page was up.
	for s in _hidden_siblings:
		if is_instance_valid(s) and ("visible" in s):
			s.set("visible", true)
	_hidden_siblings.clear()


func _position_entry() -> void:
	# If the phone menu is a normal Control in the MAIN viewport, place the tab over
	# its rect so it looks attached; otherwise (SubViewport/3D) use bottom-centre.
	if _entry_panel == null or not is_instance_valid(_entry_panel):
		return
	if _phone_root is Control and is_instance_valid(_phone_root) and not _under_viewport(_phone_root):
		var rect: Rect2 = (_phone_root as Control).get_global_rect()
		if rect.size.x > 8.0 and rect.size.y > 8.0:
			_entry_panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
			_entry_panel.global_position = rect.position + Vector2(6.0, rect.size.y + 4.0)
			return
	_entry_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_entry_panel.position = Vector2(-70.0, -120.0)


# --------------------------------------------------------------------------- #
# Overlay: phone-styled "Debug" tab + Debug page
# --------------------------------------------------------------------------- #


func _build_entry() -> void:
	_entry_panel = PanelContainer.new()
	_entry_panel.name = "PhoneDebugTab"
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.10, 0.13, 0.10, 0.92)
	style.border_color = Color(0.4, 0.9, 0.4, 0.9)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.set_content_margin_all(8)
	_entry_panel.add_theme_stylebox_override("panel", style)
	# bottom-centre, where a held phone tends to sit on screen
	_entry_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_entry_panel.position = Vector2(-70, -120)
	_entry_panel.custom_minimum_size = Vector2(140, 0)

	var btn := Button.new()
	btn.text = "📱 " + String(_cfg.get("entry_label", "Debug"))
	btn.flat = true
	btn.add_theme_color_override("font_color", Color(0.7, 1.0, 0.7))
	btn.pressed.connect(_open_page)
	_entry_panel.add_child(btn)
	add_child(_entry_panel)


func _set_entry_visible(v: bool) -> void:
	if _entry_panel != null and is_instance_valid(_entry_panel):
		_entry_panel.visible = v


func _build_page() -> void:
	_page = PanelContainer.new()
	_page.name = "PhoneDebugPage"
	_page.set_anchors_preset(Control.PRESET_CENTER)
	_page.custom_minimum_size = Vector2(330, 430)
	_page.position = Vector2(-165, -215)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.06, 0.05, 0.97)
	style.border_color = Color(0.35, 0.85, 0.45, 0.9)
	style.set_border_width_all(2)
	style.set_corner_radius_all(14)
	style.set_content_margin_all(12)
	_page.add_theme_stylebox_override("panel", style)
	add_child(_page)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	_page.add_child(vb)

	var header := Label.new()
	header.text = "▌ DEBUG ▐"
	header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	header.add_theme_font_size_override("font_size", 18)
	header.add_theme_color_override("font_color", Color(0.7, 1.0, 0.7))
	vb.add_child(header)

	var sep := HSeparator.new()
	vb.add_child(sep)

	_nav.clear()
	_add_button_row(vb, "noclip", "Noclip")
	_add_button_row(vb, "fly", "Fly")
	_add_button_row(vb, "freecam", "Freecam")
	_add_speed_row(vb)
	_add_button_row(vb, "unstuck", "Unstuck (nudge up)")
	_add_button_row(vb, "spawn", "Spawn menu…")
	# Sightless Lite calibration: only when the Sightless Lite mod is installed.
	if _ctrl_call_bool("has_flashlight_mod"):
		_add_button_row(vb, "flcalib", "Sightless Lite calibration")

	var sep2 := HSeparator.new()
	vb.add_child(sep2)

	var hint := Label.new()
	hint.name = "HintLabel"
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", Color(0.55, 0.7, 0.55))
	hint.text = "↑/↓ select · Enter activate · ←/→ on Speed · Esc/F10 close · F2-F8 hotkeys still work"
	vb.add_child(hint)


func _styled_row_button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_color_override("font_color", Color(0.85, 1.0, 0.85))
	return b


func _add_button_row(vb: VBoxContainer, kind: String, label: String) -> void:
	var b := _styled_row_button(label)
	b.pressed.connect(_activate_kind.bind(kind))
	vb.add_child(b)
	_nav.append({"button": b, "kind": kind, "label": label})


func _add_speed_row(vb: VBoxContainer) -> void:
	var row := HBoxContainer.new()
	var down := _styled_row_button("Speed −")
	var val := Label.new()
	val.name = "SpeedVal"
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val.custom_minimum_size = Vector2(90, 0)
	val.add_theme_color_override("font_color", Color(0.85, 1.0, 0.85))
	var up := _styled_row_button("Speed +")
	var rst := _styled_row_button("Reset")
	down.pressed.connect(_activate_kind.bind("speed_down"))
	up.pressed.connect(_activate_kind.bind("speed_up"))
	rst.pressed.connect(_activate_kind.bind("speed_reset"))
	row.add_child(down)
	row.add_child(val)
	row.add_child(up)
	row.add_child(rst)
	vb.add_child(row)
	# One nav entry for keyboard: ←/→ adjust, Enter resets; highlight the whole row.
	_nav.append({"button": up, "row": row, "kind": "speed", "label": "Speed"})


func _activate_kind(kind: String) -> void:
	match kind:
		"noclip":
			_ctrl_call("set_noclip", [not _ctrl_call_bool("is_noclip")])
		"fly":
			_ctrl_call("set_fly", [not _ctrl_call_bool("is_fly")])
		"freecam":
			_ctrl_call("set_freecam", [not _ctrl_call_bool("is_freecam")])
		"unstuck":
			_ctrl_call("do_unstuck", [])
		"spawn":
			_ctrl_call("open_spawn_menu", [])
		"coords":
			_ctrl_call("print_coords_public", [])
		"flcalib":
			_ctrl_call("toggle_flashlight_calibration", [])
		"speed", "speed_reset":
			_ctrl_call("reset_speed", [])
		"speed_down":
			_ctrl_call("adjust_speed", [-1])
		"speed_up":
			_ctrl_call("adjust_speed", [1])
	_refresh_page()
	_refresh_phone_page()


func _row_toggle_state(kind: String) -> int:
	# 1 = on, 0 = off, -1 = not a toggle row
	match kind:
		"noclip":
			return 1 if _ctrl_call_bool("is_noclip") else 0
		"fly":
			return 1 if _ctrl_call_bool("is_fly") else 0
		"freecam":
			return 1 if _ctrl_call_bool("is_freecam") else 0
	return -1


func _set_page_visible(v: bool) -> void:
	if _page != null and is_instance_valid(_page):
		_page.visible = v


func _refresh_page() -> void:
	if _page == null or not is_instance_valid(_page):
		return
	for i in range(_nav.size()):
		var e: Dictionary = _nav[i]
		var b: Button = e["button"]
		var st := _row_toggle_state(String(e["kind"]))
		if st >= 0:
			b.text = "%s : %s" % [e["label"], "ON" if st == 1 else "off"]
		# selection highlight (whole row for the speed row)
		var target: Control = e.get("row", b)
		target.modulate = Color(1.4, 1.4, 1.0) if i == _sel else Color(1, 1, 1)
	var sv := _page.find_child("SpeedVal", true, false)
	if sv is Label:
		(sv as Label).text = "x%0.2f" % float(_ctrl_call_num("get_speed_multiplier", 1.0))


# --------------------------------------------------------------------------- #
# Open / close + input
# --------------------------------------------------------------------------- #


func is_page_open() -> bool:
	return _page_open


# True when the in-game phone menu (or our in-phone Debug page) is open. Used by
# debug_tools to yield noclip/fly so the phone stays usable mid-air.
func is_phone_open() -> bool:
	if _phone_page != null and is_instance_valid(_phone_page) and _phone_page.visible:
		return true
	return _phone_open


func _open_page() -> void:
	if _page_open:
		return
	_page_open = true
	_sel = 0
	_set_entry_visible(false)
	_set_page_visible(true)
	_refresh_page()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	print("[Debug Menu] Debug page opened.")


func _close_page() -> void:
	if not _page_open:
		return
	_page_open = false
	_set_page_visible(false)


func _toggle_page() -> void:
	if _page_open:
		_close_page()
	else:
		_open_page()


func _input(event: InputEvent) -> void:
	if not bool(_cfg.get("integration", true)):
		return
	if String(_cfg.get("mode", "auto")) == "off":
		return
	if not (event is InputEventKey):
		return
	var ke := event as InputEventKey
	if not ke.pressed or ke.echo:
		return

	# Page navigation while the Debug page is open.
	if _page_open:
		match ke.keycode:
			KEY_ESCAPE, KEY_F10:
				_close_page()
				get_viewport().set_input_as_handled()
			KEY_UP:
				_move_sel(-1)
				get_viewport().set_input_as_handled()
			KEY_DOWN:
				_move_sel(1)
				get_viewport().set_input_as_handled()
			KEY_LEFT:
				_nav_dir("left")
				get_viewport().set_input_as_handled()
			KEY_RIGHT:
				_nav_dir("right")
				get_viewport().set_input_as_handled()
			KEY_ENTER, KEY_KP_ENTER, KEY_SPACE:
				_nav_activate()
				get_viewport().set_input_as_handled()
		return

	# No F10 keybind: F2 toggles the Control Panel, and the in-phone Debug row is
	# the menu. (Nothing to do here when the page is closed.)
	pass


func _move_sel(d: int) -> void:
	if _nav.is_empty():
		return
	_sel = wrapi(_sel + d, 0, _nav.size())
	_refresh_page()


func _nav_activate() -> void:
	if _sel < 0 or _sel >= _nav.size():
		return
	_activate_kind(String(_nav[_sel]["kind"]))


func _nav_dir(dir: String) -> void:
	if _sel < 0 or _sel >= _nav.size():
		return
	if String(_nav[_sel]["kind"]) != "speed":
		return
	if dir == "left":
		_activate_kind("speed_down")
	elif dir == "right":
		_activate_kind("speed_up")


# --------------------------------------------------------------------------- #
# Controller calls (safe duck-typed wrappers)
# --------------------------------------------------------------------------- #


func _ctrl_call(method: String, args: Array) -> void:
	if _controller != null and is_instance_valid(_controller) and _controller.has_method(method):
		_controller.callv(method, args)


func _ctrl_call_bool(method: String) -> bool:
	if _controller != null and is_instance_valid(_controller) and _controller.has_method(method):
		return bool(_controller.call(method))
	return false


func _ctrl_call_num(method: String, fallback: float) -> float:
	if _controller != null and is_instance_valid(_controller) and _controller.has_method(method):
		return float(_controller.call(method))
	return fallback


func _ctrl_call_str(method: String, fallback: String) -> String:
	if _controller != null and is_instance_valid(_controller) and _controller.has_method(method):
		return String(_controller.call(method))
	return fallback


func _keycode_from_string(s: String) -> int:
	var up := s.strip_edges().to_upper()
	if up.length() == 1:
		var c := up.unicode_at(0)
		if c >= 65 and c <= 90:  # A-Z
			return c
		if c >= 48 and c <= 57:  # 0-9
			return c
	return KEY_D
