# spawn_menu.gd - the in-game spawn menu (Godot 4), opened with F7.
#
#   * Spawn - single-player-only object spawner from discovered PackedScenes.
#
# Built and gated by debug_tools.gd, which also forces the mouse cursor visible
# while this menu is open (first-person games tend to re-capture it every frame,
# which is why clicking "did nothing" before).

extends CanvasLayer

# Mirrors the Python keyword list so networked scenes are never offered to spawn.
const NETWORK_KEYWORDS := [
	"multiplayer", "network", "netcode", "online", "coop", "co-op",
	"server", "client", "session", "lobby", "replication", "rpc",
]
const MAX_RESULTS := 2000

var _controller: Node = null
var _root: Control = null
var _tabs: TabContainer = null

var _spawn_search: LineEdit = null
var _spawn_list: ItemList = null
var _spawn_info: Label = null
var _all_paths: PackedStringArray = PackedStringArray()
var _filtered: PackedStringArray = PackedStringArray()
var _discovered := false

var _open := false
var _prev_mouse_mode := Input.MOUSE_MODE_VISIBLE


func setup(controller: Node) -> void:
	_controller = controller


func is_open() -> bool:
	return _open


func _ready() -> void:
	layer = 130
	_build_ui()
	_root.visible = false


# --------------------------------------------------------------------------- #
# UI construction
# --------------------------------------------------------------------------- #


func _build_ui() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP  # backstop: block clicks to game
	add_child(_root)

	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.35)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(560, 470)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.06, 0.06, 0.09, 0.96)
	style.set_corner_radius_all(6)
	style.set_content_margin_all(10)
	panel.add_theme_stylebox_override("panel", style)
	center.add_child(panel)

	var vb := VBoxContainer.new()
	panel.add_child(vb)

	var title := Label.new()
	title.text = "nophenia spawn menu   (F7 to close)"
	title.add_theme_font_size_override("font_size", 18)
	vb.add_child(title)

	_tabs = TabContainer.new()
	_tabs.custom_minimum_size = Vector2(540, 415)
	_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(_tabs)

	_build_spawn_tab()


func _make_button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", 16)
	b.pressed.connect(cb)
	return b


func _build_spawn_tab() -> void:
	var page := VBoxContainer.new()
	page.name = "Spawn"
	_tabs.add_child(page)

	_spawn_search = LineEdit.new()
	_spawn_search.placeholder_text = "filter scenes..."
	_spawn_search.add_theme_font_size_override("font_size", 16)
	_spawn_search.text_changed.connect(_on_search_changed)
	page.add_child(_spawn_search)

	_spawn_list = ItemList.new()
	_spawn_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_spawn_list.custom_minimum_size = Vector2(520, 300)
	_spawn_list.add_theme_font_size_override("font_size", 17)  # clearer middle text
	_spawn_list.add_theme_constant_override("v_separation", 4)
	_spawn_list.item_activated.connect(_on_spawn_activated)
	page.add_child(_spawn_list)

	var row := HBoxContainer.new()
	page.add_child(row)
	row.add_child(_make_button("Spawn selected", _on_spawn_pressed))
	row.add_child(_make_button("Refresh list", _on_spawn_refresh))

	_spawn_info = Label.new()
	_spawn_info.text = "Select a scene then Spawn (or double-click). Placed in front of you."
	_spawn_info.add_theme_font_size_override("font_size", 15)
	page.add_child(_spawn_info)


# --------------------------------------------------------------------------- #
# Open / close
# --------------------------------------------------------------------------- #


func toggle() -> void:
	if _open:
		force_close()
	else:
		_open_menu()


func _open_menu() -> void:
	if not _discovered:
		_discover()
	_apply_filter("")
	_root.visible = true
	_open = true
	_prev_mouse_mode = Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func force_close() -> void:
	if not _open:
		return
	_open = false
	if _root != null:
		_root.visible = false
	Input.mouse_mode = _prev_mouse_mode


func _selected_index(list: ItemList) -> int:
	var sel := list.get_selected_items()
	if sel.size() > 0:
		return sel[0]
	return -1


# --------------------------------------------------------------------------- #
# Spawn tab
# --------------------------------------------------------------------------- #


func _discover() -> void:
	_discovered = true
	_all_paths = PackedStringArray()
	var seen := {}
	var stack: Array[String] = ["res://"]
	while not stack.is_empty():
		var dir_path: String = stack.pop_back()
		var d := DirAccess.open(dir_path)
		if d == null:
			continue
		d.list_dir_begin()
		var entry := d.get_next()
		while entry != "":
			if d.current_is_dir():
				if not entry.begins_with("."):
					stack.append(dir_path.path_join(entry))
			else:
				var lower := entry.to_lower()
				if lower.ends_with(".remap"):
					lower = lower.substr(0, lower.length() - 6)
				if lower.ends_with(".tscn") or lower.ends_with(".scn"):
					var full := dir_path.path_join(entry)
					if full.ends_with(".remap"):
						full = full.substr(0, full.length() - 6)
					if not seen.has(full) and not _looks_networked(full):
						seen[full] = true
						_all_paths.append(full)
			if _all_paths.size() >= MAX_RESULTS:
				break
			entry = d.get_next()
		d.list_dir_end()
		if _all_paths.size() >= MAX_RESULTS:
			break
	_all_paths.sort()


func _looks_networked(path: String) -> bool:
	var lower := path.to_lower()
	for kw in NETWORK_KEYWORDS:
		if lower.find(kw) != -1:
			return true
	return false


func _on_search_changed(text: String) -> void:
	_apply_filter(text)


func _apply_filter(text: String) -> void:
	if _spawn_list == null:
		return
	_spawn_list.clear()
	_filtered = PackedStringArray()
	var needle := text.to_lower()
	for p in _all_paths:
		if needle == "" or p.to_lower().find(needle) != -1:
			_filtered.append(p)
			_spawn_list.add_item(p)
		if _filtered.size() >= 500:
			break
	if _all_paths.is_empty():
		_spawn_info.text = "No safe spawnable scenes discovered in res://."
	else:
		_spawn_info.text = "%d scene(s) shown. Select + Spawn, or double-click." % _filtered.size()


func _on_spawn_refresh() -> void:
	_discovered = false
	_discover()
	_apply_filter(_spawn_search.text)


func _on_spawn_pressed() -> void:
	var idx := _selected_index(_spawn_list)
	if idx < 0 or idx >= _filtered.size():
		_spawn_info.text = "Select a scene in the list first."
		return
	_do_spawn(_filtered[idx])


func _on_spawn_activated(index: int) -> void:
	if index >= 0 and index < _filtered.size():
		_do_spawn(_filtered[index])


func _do_spawn(path: String) -> void:
	if _controller == null:
		return
	_spawn_info.text = _controller.spawn_scene(path)
