extends Node

const MOD_DIR := "mod-audio" # Name of the directory that this file is in
const LOG_NAME := "mod-audio:Main" # Full ID of the mod (AuthorName-ModName)

func _init() -> void:
    ModLoaderLog.info("mod audio init", LOG_NAME)
    
func _ready() -> void:
    get_tree().node_added.connect(_on_node_added)
    ModLoaderLog.info("mod audio ready", LOG_NAME)

func _on_node_added(node: Node) -> void:
    if node is AudioStreamPlayer or node is AudioStreamPlayer2D or node is AudioStreamPlayer3D:
        if node.stream:
            var playing: bool = node.playing
            var pos: float = node.get_playback_position() if playing else 0.0
            var orig = node.stream.resource_path
            if orig.begins_with("res://audio"):
                var patched = ProjectSettings.globalize_path(
                    orig.replace("res://audio", "res://patched_audio")
                )
                if FileAccess.file_exists(patched):
                    var file_bytes = FileAccess.get_file_as_bytes(patched)
                    var new_stream: AudioStream = null
                    new_stream = AudioStreamOggVorbis.load_from_buffer(file_bytes)
                    node.stream = new_stream
                    if playing or node.autoplay:
                       node.play(pos)
            print("AUD:", node.stream.resource_path)
